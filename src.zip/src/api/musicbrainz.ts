import type { Album, Song } from "../types"


type MBReleaseGroup = {
    id: string;
    title: string;
    "first-release-date": string;
    "artist-credit"?: {name: string }[];
};

type MBTrack = {
    id: string;
    number: string;
    title: string;
    length?: number;
}

type MBMedium = {
    tracks?: MBTrack[];
}

type MBRelease = {
    media?: MBMedium[];
}

type MBReleaseResponse = {
    releases: MBRelease[];
}

type MBSSearchResponse = {
    count: number;
    "release-groups": MBReleaseGroup[];
};

function toAlbum(rg: MBReleaseGroup) : Album {
    return {
        id: rg.id,
        title:rg.title,
        artist: rg["artist-credit"]?.[0]?.name ?? "Unknown artist",
        year: rg["first-release-date"]
            ? Number(rg["first-release-date"].slice(0, 4))
            : undefined,
        coverUrl: `https://coverartarchive.org/release-group/${rg.id}/front-250`,
    };
} 

export async function searchAlbums(query: string) : Promise<Album[]> {

    const url = `http://musicbrainz.org/ws/2/release-group?query=${encodeURIComponent(query)}&fmt=json&limit=12`;

    await waitForTurn()
    const res = await fetch(url);

    if(!res.ok) {
        throw new Error(`Server responded with ${res.status}`)
    }

    const data: MBSSearchResponse = await res.json()

    return data["release-groups"].map(toAlbum)
}

export async function getAlbum(id: string) : Promise<Album> {
    const url = `https://musicbrainz.org/ws/2/release-group/${id}?fmt=json&inc=artist-credits`
    await waitForTurn()
    const res = await fetch(url)

    if(!res.ok) {
        throw new Error(`Server responded with ${res.status}`)
    }

    const data: MBReleaseGroup = await res.json()

    return toAlbum(data)
}

export async function getTracks(albumId: string) : Promise<Song[]> {
    const url= `https://musicbrainz.org/ws/2/release?release-group=${albumId}&fmt=json&inc=recordings&limit=1`
    await waitForTurn()
    const res = await fetch(url);

    if(!res.ok) {
        throw new Error(`Server responded with ${res.status}`)
    }

    const data: MBReleaseResponse = await res.json()

    const release = data.releases[0]
    if (!release) return []

    return (release.media ?? []).flatMap(medium => 
        (medium.tracks ?? []).map(track => ({
            id: track.id,
            title: track.title,
            durationMs: track.length,
            trackNumber: track.number,
        }))
    );
}

let nextSlot = 0

async function waitForTurn() {
    const now = Date.now()
    const wait = Math.max(0, nextSlot - now)

    nextSlot = Math.max(now, nextSlot) + 1100

    if(wait > 0) {
        await new Promise(resolve => setTimeout(resolve, wait))
    }
}