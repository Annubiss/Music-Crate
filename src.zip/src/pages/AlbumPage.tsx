import { useParams } from "react-router";
import { useEffect, useState} from "react"
import type { Album, Song } from "../types"
import { getAlbum } from "../api/musicbrainz"
import { getTracks } from "../api/musicbrainz";
import { Link } from "react-router";

type Status = "loading" | "error" | "success"

function formatDuration(ms?: number) {
    if(!ms) return ""

    const totalSeconds = Math.floor(ms / 1000)
    const minutes = Math.floor(totalSeconds /60)
    const seconds = totalSeconds % 60

    return `${minutes}:${seconds.toString().padStart(2, "0")}`
}

function AlbumPage() {
    const { id } = useParams()
    const [album, setAlbum] = useState<Album | null>(null)
    const [status, setStatus] = useState<Status>("loading")
    const [tracks, setTracks] = useState<Song[]>([])

    useEffect(() => {
        if(!id) return

        setStatus("loading")

        getAlbum(id)
            .then(result => {
            setAlbum(result)
            setStatus("success")
            return getTracks(id)
            }) 
            .then(result => {
                setTracks(result)
            })
            .catch(err => {
                console.log(err)
                setStatus("error")
            })
    }, [id])

    if(status === 'loading') {
       return <p>Loading...</p>
    }

    if(status === "error" || !album) {
        return <p>Album not found</p>
    }

    return (
        <div className="max-w-4xl mx-auto px-4 py-8">
            <Link to="/" className="text-fog text-sm hover:text-chalk transition-colors">
            ← Home
            </Link>
            <div className="flex flex-col sm:flex-row gap-8 mt-8">
            <img 
                src={album.coverUrl} 
                alt={album.title}
                className="w-full sm:w-64 aspect-square rounded-lg object-cover bg-line shrink-0"
             />
            <div className="flex flex-col justify-end">
                <p className="text-fog text-xs uppercase tracking-widest">Album</p>

                <h1 className="font-display text-5xl tracking-tight mt-2">
                    {album.title}
                </h1>

                <p className="text-chalk text-xl mt-4">{album.artist}</p>
                
                <p className="text-chalk text-sm mt-2">
                    {album.year} · {tracks.length} tracks
                </p>

                {album.year && <p className="text-fog text-sm mt-2">{album.year}</p>}


            <h2 className="font-display text-xl mt-2">Tracks:</h2>

            </div>

            <div className="mt-12 border-t border-line pt-6">
            {tracks.length === 0 ? (
                <p className="text-fog">Loading tracks...</p>
            ) : (
                <ol className="space-y-1">
                    {tracks.map(track => (
                        <li 
                        key={track.id}
                        className="flex items-center gap-4 px-3 py-2 rounded-lg hover:bg-surface transition-colors">
                            <span className="text-fog text-sm w-6 shrink-0 text-right">{track.trackNumber}.</span>
                            <span className="text-chalk truncate">{track.title}</span>

                            <span className="text-fog text-sm ml-auto shrink-0">
                                {formatDuration(track.durationMs)}
                            </span>
                        </li>
                    ))}
                </ol>
                
            )}
            </div>
        </div>
        </div>
    )
}

export default AlbumPage