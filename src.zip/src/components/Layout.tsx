import { Outlet } from "react-router"
import { useState } from "react"


export default function Layout() {
    const [isOpen, setIsOpen] = useState(false)
    return (
        <div>
            <button 
            type="button" 
            onClick={() => setIsOpen(true)}
            className={
                "fixed top-4 left-4 z-30 " + 
                "rounded-full border border-line bg-surface " + "px-4 py-2 text-sm text-chalk " +
                "cursor-pointer transition-colors " + "hover:border-accent hover-text-accent " +
                "focus-visible:outline-2 focus-visible:outline-offset-2 " +
                "focus-visible:outline-accent"
            }>
                Menu
            </button>

            <div 
                onClick={() => setIsOpen(false)}
                className={
                    "fixed inset-0 z-40 bg-black/60 " +
                    "transition-opacity duration-300 " +
                    (isOpen ? "opacity-100" : "opacity-0 pointer-events-none")
                }
            />

            <Outlet />
        </div>
    )
}